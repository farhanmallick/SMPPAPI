namespace SmppApi.Api.Models;

public sealed record DeliveryReport(string MessageId, string Status, DateTimeOffset ReceivedAtUtc, string? ErrorMessage = null);

public sealed record SmsSubmitRecord(
    string MessageId,
    string To,
    string? From,
    DateTimeOffset SubmittedAtUtc,
    DateTimeOffset LastUpdatedUtc,
    SmsDeliveryStatus Status,
    string Endpoint);
