using System.ComponentModel.DataAnnotations;

namespace SmppApi.Api.Models;

public sealed class SmsSendRequest
{
    [Required]
    // Accept E.164 format numbers like +923009276346
    [RegularExpression(@"^\+[1-9]\d{7,14}$", ErrorMessage = "To must be in E.164 format (e.g., +923009276346).")]
    public string To { get; set; } = string.Empty;

    [Required]
    [MaxLength(1600)]
    public string Message { get; set; } = string.Empty;

    [MaxLength(15)]
    public string? From { get; set; }

    public bool RequestDeliveryReport { get; set; } = true;

    /// <summary>
    /// Optional application/user metadata stored in SmsMessages (UserId/ApplicationId/Reference).
    /// </summary>
    public string? UserId { get; set; }
    public string? ApplicationId { get; set; }
    public string? Reference { get; set; }

    /// <summary>
    /// Optional: force traffic through a specific SMPP provider from SmppProviders.ProviderCode (e.g. PROVIDER1/PROVIDER2).
    /// If omitted, providers are tried in IsPrimary/Priority order (failover).
    /// </summary>
    public string? ProviderCode { get; set; }
}
