namespace SmppApi.Api.Models;

public enum SmsDeliveryStatus
{
    Pending,
    Submitted,
    Delivered,
    Expired,
    Deleted,
    Undeliverable,
    Accepted,
    Unknown,
    Rejected
}

public sealed class SmsStatusDto
{
    public long MessageId { get; init; }
    public string? ExternalMessageId { get; init; }
    public SmsDeliveryStatus Status { get; init; }
    public string? To { get; init; }
    public string? From { get; init; }
    public DateTimeOffset LastUpdatedUtc { get; init; }
    public string? Notes { get; init; }
}
