namespace SmppApi.Api.Options;

public sealed class SmppOptions
{
    /// <summary>
    /// Which SMPP client implementation to use.
    /// - "Simulated": in-process fake SMPP (default)
    /// - "Inetlab": real SMPP client using Inetlab.SMPP
    /// </summary>
    public string Client { get; set; } = "Simulated";

    public SmppEndpointOptions Primary { get; set; } = new();
    public SmppEndpointOptions? Secondary { get; set; }
    public RetryOptions Retry { get; set; } = new();
    public RateLimitOptions RateLimit { get; set; } = new();
    public int DeliveryReportBufferSize { get; set; } = 500;
}

public sealed class SmppEndpointOptions
{
    public string Host { get; set; } = "localhost";
    public int Port { get; set; } = 2775;
    public string SystemId { get; set; } = "system-id";
    public string Password { get; set; } = "password";
    public string? SystemType { get; set; }
    public string BindMode { get; set; } = "transceiver"; // transmitter | receiver | transceiver
    public bool UseTls { get; set; }
}

public sealed class RetryOptions
{
    public int MaxAttempts { get; set; } = 3;
    public double BaseDelaySeconds { get; set; } = 1;
}

public sealed class RateLimitOptions
{
    public int TransactionsPerSecond { get; set; } = 20;
    public int BurstCapacity { get; set; } = 5;
    public int QueueLimit { get; set; } = 25;
}
