using Microsoft.EntityFrameworkCore;
using SmppApi.Api.Data;
using SmppApi.Api.Data.Entities;
using SmppApi.Api.Models;

namespace SmppApi.Api.Services;

public sealed class DbSmsStore : ISmsStore
{
    private readonly SmppDbContext _db;

    public DbSmsStore(SmppDbContext db)
    {
        _db = db;
    }

    public async Task<long> CreatePendingAsync(SmsSendRequest request, int providerId, CancellationToken cancellationToken)
    {
        var entity = new SmsMessage
        {
            ProviderId = providerId,
            SourceAddress = request.From ?? string.Empty,
            DestinationAddress = request.To,
            MessageText = request.Message,
            MessageType = "TEXT",
            DataCoding = 0,
            Priority = 0,
            Status = "PENDING",
            RetryCount = 0,
            MaxRetries = 3,
            UserId = request.UserId,
            ApplicationId = request.ApplicationId,
            Reference = request.Reference,
            CreatedDate = DateTime.UtcNow
        };

        _db.SmsMessages.Add(entity);
        await _db.SaveChangesAsync(cancellationToken);
        return entity.MessageId;
    }

    public async Task MarkSubmittedAsync(long messageId, string externalMessageId, CancellationToken cancellationToken)
    {
        var entity = await _db.SmsMessages.FirstOrDefaultAsync(m => m.MessageId == messageId, cancellationToken);
        if (entity is null) return;

        entity.ExternalMessageId = externalMessageId;
        entity.Status = "SUBMITTED";
        entity.SubmittedTime = DateTime.UtcNow;
        entity.UpdatedDate = DateTime.UtcNow;
        await _db.SaveChangesAsync(cancellationToken);
    }

    public async Task UpdateFromDeliveryReportAsync(DeliveryReport report, CancellationToken cancellationToken)
    {
        var messageId = await FindMessageIdByExternalIdAsync(report.MessageId, cancellationToken);
        if (messageId is null)
        {
            return;
        }

        var msg = await _db.SmsMessages.FirstOrDefaultAsync(m => m.MessageId == messageId.Value, cancellationToken);
        if (msg is null)
        {
            return;
        }

        _db.DeliveryReports.Add(new DeliveryReportEntity
        {
            MessageId = msg.MessageId,
            ExternalMessageId = report.MessageId,
            ProviderId = msg.ProviderId,
            DlrStatus = report.Status,
            DlrText = report.ErrorMessage,
            ReceivedTime = report.ReceivedAtUtc.UtcDateTime,
            IsProcessed = true,
            ProcessedTime = DateTime.UtcNow,
            CreatedDate = DateTime.UtcNow
        });

        var newStatus = MapMessageStatusFromDlr(report.Status);
        msg.Status = newStatus;
        msg.UpdatedDate = DateTime.UtcNow;
        if (newStatus == "DELIVERED")
        {
            msg.DeliveredTime = DateTime.UtcNow;
        }

        await _db.SaveChangesAsync(cancellationToken);
    }

    public async Task<SmsStatusDto?> GetAsync(long messageId, CancellationToken cancellationToken)
    {
        var m = await _db.SmsMessages.AsNoTracking().FirstOrDefaultAsync(x => x.MessageId == messageId, cancellationToken);
        if (m is null) return null;

        return new SmsStatusDto
        {
            MessageId = m.MessageId,
            ExternalMessageId = m.ExternalMessageId,
            Status = MapDeliveryStatus(m.Status),
            To = m.DestinationAddress,
            From = m.SourceAddress,
            LastUpdatedUtc = (m.UpdatedDate ?? m.CreatedDate),
            Notes = $"ProviderId: {m.ProviderId}"
        };
    }

    public async Task<long?> FindMessageIdByExternalIdAsync(string externalMessageId, CancellationToken cancellationToken)
    {
        if (string.IsNullOrWhiteSpace(externalMessageId)) return null;

        return await _db.SmsMessages
            .AsNoTracking()
            .Where(m => m.ExternalMessageId == externalMessageId)
            .Select(m => (long?)m.MessageId)
            .FirstOrDefaultAsync(cancellationToken);
    }

    private static string MapMessageStatusFromDlr(string dlrStatus) =>
        dlrStatus?.ToUpperInvariant() switch
        {
            "DELIVRD" => "DELIVERED",
            "EXPIRED" => "EXPIRED",
            "DELETED" => "DELETED",
            "UNDELIV" => "FAILED",
            "REJECTD" => "REJECTED",
            "ACCEPTD" => "SUBMITTED",
            "UNKNOWN" => "SUBMITTED",
            _ => "SUBMITTED"
        };

    private static SmsDeliveryStatus MapDeliveryStatus(string dbStatus) =>
        dbStatus?.ToUpperInvariant() switch
        {
            "PENDING" => SmsDeliveryStatus.Pending,
            "SUBMITTED" => SmsDeliveryStatus.Submitted,
            "DELIVERED" => SmsDeliveryStatus.Delivered,
            "FAILED" => SmsDeliveryStatus.Undeliverable,
            "EXPIRED" => SmsDeliveryStatus.Expired,
            "REJECTED" => SmsDeliveryStatus.Rejected,
            _ => SmsDeliveryStatus.Unknown
        };
}

