using System.Threading.RateLimiting;
using Microsoft.Extensions.Options;
using SmppApi.Api.Models;
using SmppApi.Api.Options;

namespace SmppApi.Api.Services;

public sealed class SmppService
{
    private readonly ISmppClientAdapter _client;
    private readonly ISmsStore _store;
    private readonly IProviderRepository _providers;
    private readonly ILogger<SmppService> _logger;
    private readonly IOptionsMonitor<SmppOptions> _options;
    private TokenBucketRateLimiter _rateLimiter;

    public SmppService(
        ISmppClientAdapter client,
        ISmsStore store,
        IProviderRepository providers,
        ILogger<SmppService> logger,
        IOptionsMonitor<SmppOptions> options)
    {
        _client = client;
        _store = store;
        _providers = providers;
        _logger = logger;
        _options = options;
        _rateLimiter = BuildRateLimiter(options.CurrentValue.RateLimit);
        _options.OnChange(o => _rateLimiter = BuildRateLimiter(o.RateLimit));
    }

    public async Task<(long MessageId, string ExternalMessageId)> SendAsync(SmsSendRequest request, CancellationToken cancellationToken)
    {
        using var lease = await _rateLimiter.AcquireAsync(1, cancellationToken);
        var settings = _options.CurrentValue;

        var orderedProviders = await _providers.GetActiveProvidersOrderedAsync(cancellationToken);
        if (orderedProviders.Count == 0)
        {
            throw new InvalidOperationException("No active SMPP providers configured in SmppProviders.");
        }

        var providers = new List<SmppApi.Api.Data.Entities.SmppProvider>(orderedProviders.Count);
        if (!string.IsNullOrWhiteSpace(request.ProviderCode))
        {
            var forced = await _providers.GetByCodeAsync(request.ProviderCode.Trim(), cancellationToken);
            if (forced is null || !forced.IsActive)
            {
                throw new InvalidOperationException($"ProviderCode '{request.ProviderCode}' not found or inactive in SmppProviders.");
            }

            providers.Add(forced);
            providers.AddRange(orderedProviders.Where(p => p.ProviderId != forced.ProviderId));
        }
        else
        {
            providers.AddRange(orderedProviders);
        }

        var lastException = default(Exception);
        foreach (var provider in providers)
        {
            var endpoint = new SmppEndpointOptions
            {
                Host = provider.Host,
                Port = provider.Port,
                SystemId = provider.SystemId,
                Password = provider.Password,
                SystemType = provider.SystemType,
                BindMode = provider.BindType.ToLowerInvariant(),
                UseTls = false
            };

            var messageId = await _store.CreatePendingAsync(request, provider.ProviderId, cancellationToken);
            try
            {
                _logger.LogInformation("Binding to SMPP {Host}:{Port} as {SystemId} (ProviderCode={ProviderCode})",
                    endpoint.Host, endpoint.Port, endpoint.SystemId, provider.ProviderCode);
                await _client.BindAsync(endpoint, cancellationToken);

                var externalMessageId = await ExecuteWithRetry(
                    () => _client.SubmitAsync(new SmppSubmitRequest(request.To, request.From, request.Message, request.RequestDeliveryReport, endpoint), cancellationToken),
                    settings.Retry,
                    cancellationToken);

                await _store.MarkSubmittedAsync(messageId, externalMessageId, cancellationToken);
                _logger.LogInformation("SMS submitted to {Destination}. MessageId={MessageId}, ExternalMessageId={ExternalMessageId}",
                    request.To, messageId, externalMessageId);
                return (messageId, externalMessageId);
            }
            catch (Exception ex)
            {
                _logger.LogWarning(ex, "Failed sending via {Host}:{Port} (ProviderCode={ProviderCode}). Trying next provider if available.",
                    endpoint.Host, endpoint.Port, provider.ProviderCode);
                lastException = ex;
            }
        }

        throw new InvalidOperationException("Failed to send SMS via all configured SMPP endpoints.", lastException);
    }

    private static TokenBucketRateLimiter BuildRateLimiter(RateLimitOptions options) =>
        new(
            new TokenBucketRateLimiterOptions
            {
                TokenLimit = Math.Max(options.BurstCapacity, 1),
                TokensPerPeriod = Math.Max(options.TransactionsPerSecond, 1),
                ReplenishmentPeriod = TimeSpan.FromSeconds(1),
                QueueProcessingOrder = QueueProcessingOrder.OldestFirst,
                QueueLimit = Math.Max(options.QueueLimit, 0),
                AutoReplenishment = true
            });

    private static async Task<T> ExecuteWithRetry<T>(Func<Task<T>> action, RetryOptions retry, CancellationToken cancellationToken)
    {
        Exception? last = null;
        var delay = TimeSpan.FromSeconds(Math.Max(retry.BaseDelaySeconds, 0.25));

        for (var attempt = 1; attempt <= Math.Max(1, retry.MaxAttempts); attempt++)
        {
            try
            {
                return await action();
            }
            catch (Exception ex) when (attempt < retry.MaxAttempts)
            {
                last = ex;
                await Task.Delay(delay, cancellationToken);
                delay = TimeSpan.FromSeconds(delay.TotalSeconds * 2);
            }
            catch (Exception ex)
            {
                last = ex;
            }
        }

        throw new InvalidOperationException("Exceeded retry attempts for SMPP submit.", last);
    }

    // Provider ordering/failover is driven from the SmppProviders table.
}
