using Microsoft.EntityFrameworkCore;
using SmppApi.Api.Data;
using SmppApi.Api.Data.Entities;

namespace SmppApi.Api.Services;

public sealed class ProviderRepository : IProviderRepository
{
    private readonly SmppDbContext _db;

    public ProviderRepository(SmppDbContext db)
    {
        _db = db;
    }

    public async Task<IReadOnlyList<SmppProvider>> GetActiveProvidersOrderedAsync(CancellationToken cancellationToken)
    {
        return await _db.SmppProviders
            .AsNoTracking()
            .Where(p => p.IsActive)
            .OrderByDescending(p => p.IsPrimary)
            .ThenBy(p => p.Priority)
            .ToListAsync(cancellationToken);
    }

    public Task<SmppProvider?> GetByIdAsync(int providerId, CancellationToken cancellationToken) =>
        _db.SmppProviders.AsNoTracking().FirstOrDefaultAsync(p => p.ProviderId == providerId, cancellationToken);

    public Task<SmppProvider?> GetByCodeAsync(string providerCode, CancellationToken cancellationToken) =>
        _db.SmppProviders.AsNoTracking().FirstOrDefaultAsync(p => p.ProviderCode == providerCode, cancellationToken);
}

