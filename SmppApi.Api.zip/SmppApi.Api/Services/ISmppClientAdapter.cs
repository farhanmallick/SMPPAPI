using System.Threading.Channels;
using SmppApi.Api.Models;
using SmppApi.Api.Options;

namespace SmppApi.Api.Services;

public interface ISmppClientAdapter
{
    ChannelReader<DeliveryReport> DeliveryReports { get; }

    Task BindAsync(SmppEndpointOptions endpoint, CancellationToken cancellationToken);

    Task<string> SubmitAsync(SmppSubmitRequest request, CancellationToken cancellationToken);

    Task UnbindAsync(CancellationToken cancellationToken);
}

public sealed record SmppSubmitRequest(string To, string? From, string Message, bool RequestDeliveryReport, SmppEndpointOptions Endpoint);
