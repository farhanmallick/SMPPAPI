using System.Text.RegularExpressions;
using System.Threading.Channels;
using Inetlab.SMPP;
using Inetlab.SMPP.Common;
using Inetlab.SMPP.Builders;
using Inetlab.SMPP.PDU;
using SmppApi.Api.Models;
using SmppApi.Api.Options;

namespace SmppApi.Api.Services;

/// <summary>
/// Real SMPP client adapter using Inetlab.SMPP. Works with SMPPSim/Jasmin test setups.
/// </summary>
public sealed class InetlabSmppClientAdapter : ISmppClientAdapter, IDisposable
{
    private readonly ILogger<InetlabSmppClientAdapter> _logger;
    private readonly Channel<DeliveryReport> _deliveryReports;
    private readonly SemaphoreSlim _sync = new(1, 1);
    private SmppClient? _client;
    private SmppEndpointOptions? _boundEndpoint;
    private bool _isBound;

    private static readonly Regex DlrId = new(@"(?:^|\s)id:(?<id>[^\s]+)", RegexOptions.Compiled | RegexOptions.IgnoreCase);
    private static readonly Regex DlrStat = new(@"(?:^|\s)stat:(?<stat>[^\s]+)", RegexOptions.Compiled | RegexOptions.IgnoreCase);

    public InetlabSmppClientAdapter(ILogger<InetlabSmppClientAdapter> logger)
    {
        _logger = logger;
        _deliveryReports = Channel.CreateUnbounded<DeliveryReport>(new UnboundedChannelOptions { SingleWriter = false, SingleReader = false });
    }

    public ChannelReader<DeliveryReport> DeliveryReports => _deliveryReports.Reader;

    public async Task BindAsync(SmppEndpointOptions endpoint, CancellationToken cancellationToken)
    {
        await _sync.WaitAsync(cancellationToken);
        try
        {
            if (_client is not null && _isBound && _boundEndpoint?.Host == endpoint.Host && _boundEndpoint?.Port == endpoint.Port)
            {
                return; // already bound to this endpoint
            }

            await UnbindInternalAsync(cancellationToken);

            _client = new SmppClient();
            _client.evDeliverSm += OnDeliverSm;
            _client.SystemType = endpoint.SystemType;

            await _client.ConnectAsync(endpoint.Host, endpoint.Port);
            cancellationToken.ThrowIfCancellationRequested();

            var mode = (endpoint.BindMode ?? "transceiver").ToLowerInvariant();
            var connMode = mode switch
            {
                "transmitter" => Inetlab.SMPP.Common.ConnectionMode.Transmitter,
                "receiver" => Inetlab.SMPP.Common.ConnectionMode.Receiver,
                _ => Inetlab.SMPP.Common.ConnectionMode.Transceiver
            };

            var resp = await _client.BindAsync(endpoint.SystemId, endpoint.Password, connMode);
            cancellationToken.ThrowIfCancellationRequested();

            if (resp.Header.Status != Inetlab.SMPP.Common.CommandStatus.ESME_ROK)
            {
                throw new InvalidOperationException($"SMPP bind failed: {resp.Header.Status}");
            }

            _boundEndpoint = endpoint;
            _isBound = true;
        }
        finally
        {
            _sync.Release();
        }
    }

    public async Task<string> SubmitAsync(SmppSubmitRequest request, CancellationToken cancellationToken)
    {
        await _sync.WaitAsync(cancellationToken);
        try
        {
            if (_client is null || !_isBound)
            {
                throw new InvalidOperationException("Client not bound. Call BindAsync first.");
            }

            var submitSm = new SubmitSm
            {
                SourceAddress = new SmeAddress(request.From ?? string.Empty),
                DestinationAddress = new SmeAddress(request.To),
                SMSCReceipt = request.RequestDeliveryReport 
                    ? SMSCDeliveryReceipt.SuccessOrFailure 
                    : SMSCDeliveryReceipt.NotRequested
            };
            var messageBytes = _client.EncodingMapper.GetMessageBytes(request.Message, DataCodings.Default);
            submitSm.UserData = new UserData { ShortMessage = messageBytes };

            cancellationToken.ThrowIfCancellationRequested();
            var resp = await _client.SubmitAsync(submitSm);
            if (resp.Header.Status != Inetlab.SMPP.Common.CommandStatus.ESME_ROK)
            {
                throw new InvalidOperationException($"SMPP submit failed: {resp.Header.Status}");
            }

            return resp.MessageId;
        }
        finally
        {
            _sync.Release();
        }
    }

    public async Task UnbindAsync(CancellationToken cancellationToken)
    {
        await _sync.WaitAsync(cancellationToken);
        try
        {
            await UnbindInternalAsync(cancellationToken);
        }
        finally
        {
            _sync.Release();
        }
    }

    private async Task UnbindInternalAsync(CancellationToken cancellationToken = default)
    {
        if (_client is null) return;
        try
        {
            if (_isBound)
            {
                await _client.UnbindAsync();
            }
        }
        catch (Exception ex)
        {
            _logger.LogDebug(ex, "Ignoring SMPP unbind error.");
        }
        finally
        {
            try { await _client.DisconnectAsync(); } catch { /* ignore */ }
            _client.evDeliverSm -= OnDeliverSm;
            _client.Dispose();
            _client = null;
            _boundEndpoint = null;
            _isBound = false;
        }
    }

    private async void OnDeliverSm(object? sender, DeliverSm data)
    {
        try
        {
            var client = _client;
            var text = client is not null ? data.GetMessageText(client.EncodingMapper) : null;
            var id = TryParse(text, DlrId);
            var stat = TryParse(text, DlrStat) ?? "UNKNOWN";

            if (!string.IsNullOrWhiteSpace(id))
            {
                await _deliveryReports.Writer.WriteAsync(new DeliveryReport(id, stat, DateTimeOffset.UtcNow, text));
            }
        }
        catch (Exception ex)
        {
            _logger.LogWarning(ex, "Failed to process DELIVER_SM.");
        }
    }

    private static string? TryParse(string? text, Regex regex)
    {
        if (string.IsNullOrWhiteSpace(text)) return null;
        var m = regex.Match(text);
        return m.Success ? m.Groups[1].Value : null;
    }

    public void Dispose()
    {
        _client?.Dispose();
        _sync.Dispose();
    }
}

