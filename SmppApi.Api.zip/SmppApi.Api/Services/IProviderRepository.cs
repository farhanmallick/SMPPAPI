using SmppApi.Api.Data.Entities;

namespace SmppApi.Api.Services;

public interface IProviderRepository
{
    Task<IReadOnlyList<SmppProvider>> GetActiveProvidersOrderedAsync(CancellationToken cancellationToken);
    Task<SmppProvider?> GetByIdAsync(int providerId, CancellationToken cancellationToken);
    Task<SmppProvider?> GetByCodeAsync(string providerCode, CancellationToken cancellationToken);
}

