using System.Collections.Concurrent;
using System.Threading.Channels;
using SmppApi.Api.Models;
using SmppApi.Api.Options;

namespace SmppApi.Api.Services;

/// <summary>
/// Placeholder SMPP client adapter. Replace with a real SMPP client (e.g., Inetlab.SMPP) in production.
/// Simulates submit + delivery report callbacks so the API surface can be exercised end-to-end.
/// </summary>
public sealed class SimulatedSmppClientAdapter : ISmppClientAdapter
{
    private readonly Channel<DeliveryReport> _deliveryReports;
    private readonly ConcurrentDictionary<string, SmppEndpointOptions> _activeBinds = new();
    private readonly Random _random = new();

    public SimulatedSmppClientAdapter()
    {
        _deliveryReports = Channel.CreateUnbounded<DeliveryReport>(new UnboundedChannelOptions
        {
            SingleReader = false,
            SingleWriter = false
        });
    }

    public ChannelReader<DeliveryReport> DeliveryReports => _deliveryReports.Reader;

    public Task BindAsync(SmppEndpointOptions endpoint, CancellationToken cancellationToken)
    {
        _activeBinds[endpoint.Host] = endpoint;
        return Task.CompletedTask;
    }

    public async Task<string> SubmitAsync(SmppSubmitRequest request, CancellationToken cancellationToken)
    {
        if (!_activeBinds.ContainsKey(request.Endpoint.Host))
        {
            throw new InvalidOperationException("Client not bound. Call BindAsync first.");
        }

        var messageId = Guid.NewGuid().ToString("N");

        // Simulate async delivery report.
        _ = Task.Run(async () =>
        {
            try
            {
                await Task.Delay(TimeSpan.FromMilliseconds(_random.Next(500, 2000)), cancellationToken);
                var status = _random.NextDouble() > 0.1 ? "DELIVRD" : "UNDELIV";
                await _deliveryReports.Writer.WriteAsync(new DeliveryReport(messageId, status, DateTimeOffset.UtcNow), cancellationToken);
            }
            catch (OperationCanceledException)
            {
                // ignore cancellations in the simulation
            }
        }, cancellationToken);

        return await Task.FromResult(messageId);
    }

    public Task UnbindAsync(CancellationToken cancellationToken)
    {
        _activeBinds.Clear();
        return Task.CompletedTask;
    }
}
