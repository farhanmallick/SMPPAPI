using SmppApi.Api.Models;

namespace SmppApi.Api.Services;

public sealed class DeliveryReportWorker : BackgroundService
{
    private readonly ISmppClientAdapter _client;
    private readonly IServiceScopeFactory _scopeFactory;
    private readonly ILogger<DeliveryReportWorker> _logger;

    public DeliveryReportWorker(ISmppClientAdapter client, IServiceScopeFactory scopeFactory, ILogger<DeliveryReportWorker> logger)
    {
        _client = client;
        _scopeFactory = scopeFactory;
        _logger = logger;
    }

    protected override async Task ExecuteAsync(CancellationToken stoppingToken)
    {
        try
        {
            await foreach (var report in _client.DeliveryReports.ReadAllAsync(stoppingToken))
            {
                using var scope = _scopeFactory.CreateScope();
                var store = scope.ServiceProvider.GetRequiredService<ISmsStore>();
                await store.UpdateFromDeliveryReportAsync(report, stoppingToken);
                _logger.LogInformation("Delivery report received. MessageId={MessageId}, Status={Status}", report.MessageId, report.Status);
            }
        }
        catch (OperationCanceledException) when (stoppingToken.IsCancellationRequested)
        {
            // Expected during graceful shutdown / debugger stop.
        }
    }
}
