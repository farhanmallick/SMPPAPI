using SmppApi.Api.Models;

namespace SmppApi.Api.Services;

public interface ISmsStore
{
    Task<long> CreatePendingAsync(SmsSendRequest request, int providerId, CancellationToken cancellationToken);

    Task MarkSubmittedAsync(long messageId, string externalMessageId, CancellationToken cancellationToken);

    Task UpdateFromDeliveryReportAsync(DeliveryReport report, CancellationToken cancellationToken);

    Task<SmsStatusDto?> GetAsync(long messageId, CancellationToken cancellationToken);

    Task<long?> FindMessageIdByExternalIdAsync(string externalMessageId, CancellationToken cancellationToken);
}

// InMemorySmsStore removed in favor of DbSmsStore which persists to SmppSmsSystem schema.
