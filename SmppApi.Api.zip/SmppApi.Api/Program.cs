using SmppApi.Api.Options;
using SmppApi.Api.Services;
using Microsoft.EntityFrameworkCore;
using SmppApi.Api.Data;
using Scalar.AspNetCore;

var builder = WebApplication.CreateBuilder(args);

builder.Services.Configure<SmppOptions>(builder.Configuration.GetSection("Smpp"));
builder.Services.AddOpenApi();
builder.Services.AddControllers();

builder.Services.AddDbContext<SmppDbContext>(o =>
    o.UseSqlServer(builder.Configuration.GetConnectionString("SmppSmsSystem")));

var smppOptions = builder.Configuration.GetSection("Smpp").Get<SmppOptions>() ?? new SmppOptions();
if (string.Equals(smppOptions.Client, "Inetlab", StringComparison.OrdinalIgnoreCase))
{
    builder.Services.AddSingleton<ISmppClientAdapter, InetlabSmppClientAdapter>();
}
else
{
    builder.Services.AddSingleton<ISmppClientAdapter, SimulatedSmppClientAdapter>();
}
builder.Services.AddScoped<ISmsStore, DbSmsStore>();
builder.Services.AddScoped<IProviderRepository, ProviderRepository>();
builder.Services.AddScoped<SmppService>();
builder.Services.AddHostedService<DeliveryReportWorker>();

var app = builder.Build();

if (app.Environment.IsDevelopment())
{
    app.MapOpenApi();
    app.MapScalarApiReference(options =>
    {
        options.Title = "SMPP API";
        options.OpenApiRoutePattern = "/openapi/v1.json";
    });
}

app.UseHttpsRedirection();
app.MapControllers();

await app.RunAsync();
