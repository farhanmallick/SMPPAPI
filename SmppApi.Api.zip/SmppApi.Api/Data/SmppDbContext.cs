using Microsoft.EntityFrameworkCore;
using SmppApi.Api.Data.Entities;

namespace SmppApi.Api.Data;

public sealed class SmppDbContext : DbContext
{
    public SmppDbContext(DbContextOptions<SmppDbContext> options) : base(options) { }

    public DbSet<SmppProvider> SmppProviders => Set<SmppProvider>();
    public DbSet<SmsMessage> SmsMessages => Set<SmsMessage>();
    public DbSet<DeliveryReportEntity> DeliveryReports => Set<DeliveryReportEntity>();

    protected override void OnModelCreating(ModelBuilder modelBuilder)
    {
        modelBuilder.Entity<SmppProvider>(b =>
        {
            b.ToTable("SmppProviders");
            b.HasKey(x => x.ProviderId);
            b.Property(x => x.ProviderName).HasMaxLength(100).IsRequired();
            b.Property(x => x.ProviderCode).HasMaxLength(50).IsRequired();
            b.HasIndex(x => x.ProviderCode).IsUnique();
            b.Property(x => x.Host).HasMaxLength(255).IsRequired();
            b.Property(x => x.SystemId).HasMaxLength(100).IsRequired();
            b.Property(x => x.Password).HasMaxLength(255).IsRequired();
            b.Property(x => x.SystemType).HasMaxLength(50);
            b.Property(x => x.BindType).HasMaxLength(20).IsRequired();
            b.Property(x => x.CreatedBy).HasMaxLength(100);
            b.Property(x => x.UpdatedBy).HasMaxLength(100);
        });

        modelBuilder.Entity<SmsMessage>(b =>
        {
            b.ToTable("SmsMessages");
            b.HasKey(x => x.MessageId);
            b.Property(x => x.ExternalMessageId).HasMaxLength(100);
            b.HasIndex(x => x.ExternalMessageId);
            b.Property(x => x.SourceAddress).HasMaxLength(20).IsRequired();
            b.Property(x => x.DestinationAddress).HasMaxLength(20).IsRequired();
            b.Property(x => x.MessageType).HasMaxLength(20).IsRequired();
            b.Property(x => x.Status).HasMaxLength(50).IsRequired();
            b.Property(x => x.ErrorCode).HasMaxLength(50);
            b.Property(x => x.ErrorMessage).HasMaxLength(500);
            b.Property(x => x.UserId).HasMaxLength(100);
            b.Property(x => x.ApplicationId).HasMaxLength(100);
            b.Property(x => x.Reference).HasMaxLength(100);
            b.Property(x => x.Cost).HasColumnType("decimal(10,4)");

            b.HasOne(x => x.Provider)
                .WithMany()
                .HasForeignKey(x => x.ProviderId)
                .HasConstraintName("FK_SmsMessages_Provider");
        });

        modelBuilder.Entity<DeliveryReportEntity>(b =>
        {
            b.ToTable("DeliveryReports");
            b.HasKey(x => x.DlrId);
            b.Property(x => x.ExternalMessageId).HasMaxLength(100).IsRequired();
            b.HasIndex(x => x.ExternalMessageId);
            b.Property(x => x.DlrStatus).HasMaxLength(50).IsRequired();
            b.Property(x => x.ErrorCode).HasMaxLength(50);
            b.Property(x => x.NetworkCode).HasMaxLength(50);

            b.HasOne(x => x.Message)
                .WithMany()
                .HasForeignKey(x => x.MessageId)
                .HasConstraintName("FK_DeliveryReports_Message");

            b.HasOne(x => x.Provider)
                .WithMany()
                .HasForeignKey(x => x.ProviderId)
                .HasConstraintName("FK_DeliveryReports_Provider");
        });
    }
}

