namespace SmppApi.Api.Data.Entities;

public sealed class DeliveryReportEntity
{
    public long DlrId { get; set; }
    public long MessageId { get; set; }
    public string ExternalMessageId { get; set; } = string.Empty;
    public int ProviderId { get; set; }
    public string DlrStatus { get; set; } = string.Empty;
    public string? DlrText { get; set; }
    public string? ErrorCode { get; set; }
    public string? NetworkCode { get; set; }
    public DateTime ReceivedTime { get; set; }
    public DateTime? ProcessedTime { get; set; }
    public bool IsProcessed { get; set; }
    public DateTime CreatedDate { get; set; }

    public SmsMessage? Message { get; set; }
    public SmppProvider? Provider { get; set; }
}
