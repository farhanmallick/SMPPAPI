namespace SmppApi.Api.Data.Entities;

public sealed class SmsMessage
{
    public long MessageId { get; set; }
    public string? ExternalMessageId { get; set; }
    public int ProviderId { get; set; }
    public string SourceAddress { get; set; } = string.Empty;
    public string DestinationAddress { get; set; } = string.Empty;
    public string MessageText { get; set; } = string.Empty;
    public string MessageType { get; set; } = "TEXT";
    public int DataCoding { get; set; } = 0;
    public int Priority { get; set; } = 0;
    public int? ValidityPeriod { get; set; }
    public DateTime? ScheduledTime { get; set; }
    public DateTime? SubmittedTime { get; set; }
    public DateTime? DeliveredTime { get; set; }
    public string Status { get; set; } = "PENDING";
    public string? ErrorCode { get; set; }
    public string? ErrorMessage { get; set; }
    public int RetryCount { get; set; } = 0;
    public int MaxRetries { get; set; } = 3;
    public int TotalSegments { get; set; } = 1;
    public int SegmentNumber { get; set; } = 1;
    public string? UserId { get; set; }
    public string? ApplicationId { get; set; }
    public string? Reference { get; set; }
    public decimal? Cost { get; set; }
    public DateTime CreatedDate { get; set; }
    public DateTime? UpdatedDate { get; set; }

    public SmppProvider? Provider { get; set; }
}
