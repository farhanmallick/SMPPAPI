namespace SmppApi.Api.Data.Entities;

public sealed class SmppProvider
{
    public int ProviderId { get; set; }
    public string ProviderName { get; set; } = string.Empty;
    public string ProviderCode { get; set; } = string.Empty;
    public string Host { get; set; } = string.Empty;
    public int Port { get; set; } = 2775;
    public string SystemId { get; set; } = string.Empty;
    public string Password { get; set; } = string.Empty;
    public string? SystemType { get; set; }
    public string BindType { get; set; } = "TRANSCEIVER";
    public bool IsActive { get; set; } = true;
    public bool IsPrimary { get; set; }
    public int Priority { get; set; } = 1;
    public int MaxTPS { get; set; } = 10;
    public DateTime CreatedDate { get; set; }
    public DateTime? UpdatedDate { get; set; }
    public string? CreatedBy { get; set; }
    public string? UpdatedBy { get; set; }
}
