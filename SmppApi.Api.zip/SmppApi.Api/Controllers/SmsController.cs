using Microsoft.AspNetCore.Mvc;
using SmppApi.Api.Models;
using SmppApi.Api.Services;

namespace SmppApi.Api.Controllers;

[ApiController]
[Route("api/sms")]
public class SmsController : ControllerBase
{
    private readonly SmppService _smppService;
    private readonly ISmsStore _store;
    private readonly ILogger<SmsController> _logger;

    public SmsController(SmppService smppService, ISmsStore store, ILogger<SmsController> logger)
    {
        _smppService = smppService;
        _store = store;
        _logger = logger;
    }

    [HttpPost]
    public async Task<ActionResult<SmsStatusDto>> SendAsync([FromBody] SmsSendRequest request, CancellationToken cancellationToken)
    {
        if (!ModelState.IsValid)
        {
            return ValidationProblem(ModelState);
        }

        try
        {
            var result = await _smppService.SendAsync(request, cancellationToken);
            var status = await _store.GetAsync(result.MessageId, cancellationToken);
            return Created($"/api/sms/{result.MessageId}", status);
        }
        catch (Exception ex)
        {
            _logger.LogError(ex, "Error sending SMS to {Destination}", request.To);
            return Problem("Failed to send SMS. Check logs for details.");
        }
    }

    [HttpGet("{messageId}")]
    public async Task<ActionResult<SmsStatusDto>> GetStatusAsync(long messageId, CancellationToken cancellationToken)
    {
        var status = await _store.GetAsync(messageId, cancellationToken);
        return status is not null ? Ok(status) : NotFound();
    }
}
