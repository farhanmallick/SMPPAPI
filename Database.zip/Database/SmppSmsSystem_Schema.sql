-- ============================================
-- SMPP SMS Database Schema (DBBravo)
-- Database: SmppSmsSystem
-- Description: Complete database schema for SMPP SMS implementation
-- ============================================

-- Create Database
CREATE DATABASE SmppSmsSystem;
GO

USE SmppSmsSystem;
GO

-- Required SET options for filtered indexes
SET QUOTED_IDENTIFIER ON;
SET ANSI_NULLS ON;
GO

-- ============================================
-- 1. SMPP Provider Configuration
-- ============================================
CREATE TABLE SmppProviders (
    ProviderId INT PRIMARY KEY IDENTITY(1,1),
    ProviderName NVARCHAR(100) NOT NULL,
    ProviderCode NVARCHAR(50) NOT NULL UNIQUE,
    Host NVARCHAR(255) NOT NULL,
    Port INT NOT NULL DEFAULT 2775,
    SystemId NVARCHAR(100) NOT NULL,
    Password NVARCHAR(255) NOT NULL, -- Store encrypted
    SystemType NVARCHAR(50) NULL,
    BindType NVARCHAR(20) NOT NULL DEFAULT 'TRANSCEIVER', -- TRANSMITTER, RECEIVER, TRANSCEIVER
    IsActive BIT NOT NULL DEFAULT 1,
    IsPrimary BIT NOT NULL DEFAULT 0,
    Priority INT NOT NULL DEFAULT 1, -- For failover ordering
    MaxTPS INT NOT NULL DEFAULT 10, -- Transactions per second limit
    CreatedDate DATETIME NOT NULL DEFAULT GETDATE(),
    UpdatedDate DATETIME NULL,
    CreatedBy NVARCHAR(100) NULL,
    UpdatedBy NVARCHAR(100) NULL
);

-- ============================================
-- 2. SMS Messages (Main Transaction Table)
-- ============================================
CREATE TABLE SmsMessages (
    MessageId BIGINT PRIMARY KEY IDENTITY(1,1),
    ExternalMessageId NVARCHAR(100) NULL, -- Message ID from SMPP provider
    ProviderId INT NOT NULL,
    SourceAddress NVARCHAR(20) NOT NULL, -- Sender ID
    DestinationAddress NVARCHAR(20) NOT NULL, -- Phone number
    MessageText NVARCHAR(MAX) NOT NULL,
    MessageType NVARCHAR(20) NOT NULL DEFAULT 'TEXT', -- TEXT, UNICODE, BINARY
    DataCoding INT NOT NULL DEFAULT 0, -- SMPP data coding scheme
    Priority INT NOT NULL DEFAULT 0, -- 0=Normal, 1=High
    ValidityPeriod INT NULL, -- In minutes
    ScheduledTime DATETIME NULL, -- For scheduled SMS
    SubmittedTime DATETIME NULL,
    DeliveredTime DATETIME NULL,
    Status NVARCHAR(50) NOT NULL DEFAULT 'PENDING', -- PENDING, SUBMITTED, DELIVERED, FAILED, EXPIRED, REJECTED
    ErrorCode NVARCHAR(50) NULL,
    ErrorMessage NVARCHAR(500) NULL,
    RetryCount INT NOT NULL DEFAULT 0,
    MaxRetries INT NOT NULL DEFAULT 3,
    TotalSegments INT NOT NULL DEFAULT 1, -- For long SMS
    SegmentNumber INT NOT NULL DEFAULT 1,
    UserId NVARCHAR(100) NULL, -- Application user who sent SMS
    ApplicationId NVARCHAR(100) NULL, -- Source application
    Reference NVARCHAR(100) NULL, -- External reference number
    Cost DECIMAL(10,4) NULL, -- SMS cost
    CreatedDate DATETIME NOT NULL DEFAULT GETDATE(),
    UpdatedDate DATETIME NULL,
    CONSTRAINT FK_SmsMessages_Provider FOREIGN KEY (ProviderId) REFERENCES SmppProviders(ProviderId)
);

-- ============================================
-- 3. Delivery Reports (DLR)
-- ============================================
CREATE TABLE DeliveryReports (
    DlrId BIGINT PRIMARY KEY IDENTITY(1,1),
    MessageId BIGINT NOT NULL,
    ExternalMessageId NVARCHAR(100) NOT NULL,
    ProviderId INT NOT NULL,
    DlrStatus NVARCHAR(50) NOT NULL, -- DELIVRD, EXPIRED, DELETED, UNDELIV, ACCEPTD, UNKNOWN, REJECTD
    DlrText NVARCHAR(MAX) NULL,
    ErrorCode NVARCHAR(50) NULL,
    NetworkCode NVARCHAR(50) NULL, -- Mobile network operator code
    ReceivedTime DATETIME NOT NULL DEFAULT GETDATE(),
    ProcessedTime DATETIME NULL,
    IsProcessed BIT NOT NULL DEFAULT 0,
    CreatedDate DATETIME NOT NULL DEFAULT GETDATE(),
    CONSTRAINT FK_DeliveryReports_Message FOREIGN KEY (MessageId) REFERENCES SmsMessages(MessageId),
    CONSTRAINT FK_DeliveryReports_Provider FOREIGN KEY (ProviderId) REFERENCES SmppProviders(ProviderId)
);

-- ============================================
-- 4. SMPP Connection Logs
-- ============================================
CREATE TABLE SmppConnectionLogs (
    LogId BIGINT PRIMARY KEY IDENTITY(1,1),
    ProviderId INT NOT NULL,
    ConnectionType NVARCHAR(20) NOT NULL, -- CONNECT, BIND, UNBIND, DISCONNECT
    Status NVARCHAR(20) NOT NULL, -- SUCCESS, FAILED
    ErrorMessage NVARCHAR(500) NULL,
    ServerResponse NVARCHAR(MAX) NULL,
    ConnectionTime DATETIME NOT NULL DEFAULT GETDATE(),
    DisconnectionTime DATETIME NULL,
    Duration INT NULL, -- Connection duration in seconds
    CreatedDate DATETIME NOT NULL DEFAULT GETDATE(),
    CONSTRAINT FK_SmppConnectionLogs_Provider FOREIGN KEY (ProviderId) REFERENCES SmppProviders(ProviderId)
);

-- ============================================
-- 5. SMS Queue (For throttling and rate limiting)
-- ============================================
CREATE TABLE SmsQueue (
    QueueId BIGINT PRIMARY KEY IDENTITY(1,1),
    MessageId BIGINT NOT NULL,
    ProviderId INT NOT NULL,
    QueueStatus NVARCHAR(20) NOT NULL DEFAULT 'QUEUED', -- QUEUED, PROCESSING, COMPLETED, FAILED
    Priority INT NOT NULL DEFAULT 0,
    ScheduledTime DATETIME NULL,
    ProcessedTime DATETIME NULL,
    RetryCount INT NOT NULL DEFAULT 0,
    CreatedDate DATETIME NOT NULL DEFAULT GETDATE(),
    UpdatedDate DATETIME NULL,
    CONSTRAINT FK_SmsQueue_Message FOREIGN KEY (MessageId) REFERENCES SmsMessages(MessageId),
    CONSTRAINT FK_SmsQueue_Provider FOREIGN KEY (ProviderId) REFERENCES SmppProviders(ProviderId)
);

-- ============================================
-- 6. System Logs (Application level logging)
-- ============================================
CREATE TABLE SystemLogs (
    LogId BIGINT PRIMARY KEY IDENTITY(1,1),
    LogLevel NVARCHAR(20) NOT NULL, -- INFO, WARNING, ERROR, CRITICAL
    Category NVARCHAR(100) NOT NULL, -- CONNECTION, SUBMISSION, DELIVERY, RETRY, FAILOVER
    Message NVARCHAR(MAX) NOT NULL,
    Exception NVARCHAR(MAX) NULL,
    StackTrace NVARCHAR(MAX) NULL,
    MessageId BIGINT NULL,
    ProviderId INT NULL,
    UserId NVARCHAR(100) NULL,
    MachineName NVARCHAR(100) NULL,
    CreatedDate DATETIME NOT NULL DEFAULT GETDATE(),
    CONSTRAINT FK_SystemLogs_Message FOREIGN KEY (MessageId) REFERENCES SmsMessages(MessageId),
    CONSTRAINT FK_SystemLogs_Provider FOREIGN KEY (ProviderId) REFERENCES SmppProviders(ProviderId)
);

-- ============================================
-- 7. Rate Limit Tracking
-- ============================================
CREATE TABLE RateLimitTracking (
    TrackingId BIGINT PRIMARY KEY IDENTITY(1,1),
    ProviderId INT NOT NULL,
    WindowStart DATETIME NOT NULL,
    WindowEnd DATETIME NOT NULL,
    MessageCount INT NOT NULL DEFAULT 0,
    MaxAllowed INT NOT NULL,
    CreatedDate DATETIME NOT NULL DEFAULT GETDATE(),
    CONSTRAINT FK_RateLimitTracking_Provider FOREIGN KEY (ProviderId) REFERENCES SmppProviders(ProviderId)
);

-- ============================================
-- 8. SMS Templates (Optional - for common messages)
-- ============================================
CREATE TABLE SmsTemplates (
    TemplateId INT PRIMARY KEY IDENTITY(1,1),
    TemplateName NVARCHAR(100) NOT NULL UNIQUE,
    TemplateCode NVARCHAR(50) NOT NULL UNIQUE,
    MessageText NVARCHAR(MAX) NOT NULL,
    Parameters NVARCHAR(500) NULL, -- JSON array of parameter names
    IsActive BIT NOT NULL DEFAULT 1,
    CreatedDate DATETIME NOT NULL DEFAULT GETDATE(),
    UpdatedDate DATETIME NULL,
    CreatedBy NVARCHAR(100) NULL,
    UpdatedBy NVARCHAR(100) NULL
);

-- ============================================
-- 9. Failover History
-- ============================================
CREATE TABLE FailoverHistory (
    FailoverId BIGINT PRIMARY KEY IDENTITY(1,1),
    FromProviderId INT NOT NULL,
    ToProviderId INT NOT NULL,
    Reason NVARCHAR(500) NOT NULL,
    MessageId BIGINT NULL,
    FailoverTime DATETIME NOT NULL DEFAULT GETDATE(),
    Status NVARCHAR(20) NOT NULL, -- SUCCESS, FAILED
    CreatedDate DATETIME NOT NULL DEFAULT GETDATE(),
    CONSTRAINT FK_FailoverHistory_FromProvider FOREIGN KEY (FromProviderId) REFERENCES SmppProviders(ProviderId),
    CONSTRAINT FK_FailoverHistory_ToProvider FOREIGN KEY (ToProviderId) REFERENCES SmppProviders(ProviderId),
    CONSTRAINT FK_FailoverHistory_Message FOREIGN KEY (MessageId) REFERENCES SmsMessages(MessageId)
);

-- ============================================
-- 10. Performance Metrics
-- ============================================
CREATE TABLE PerformanceMetrics (
    MetricId BIGINT PRIMARY KEY IDENTITY(1,1),
    ProviderId INT NOT NULL,
    MetricDate DATE NOT NULL,
    MetricHour INT NOT NULL, -- 0-23
    TotalMessages INT NOT NULL DEFAULT 0,
    SuccessfulMessages INT NOT NULL DEFAULT 0,
    FailedMessages INT NOT NULL DEFAULT 0,
    AverageDeliveryTime INT NULL, -- In seconds
    AverageLatency INT NULL, -- In milliseconds
    MaxTPS INT NULL,
    CreatedDate DATETIME NOT NULL DEFAULT GETDATE(),
    CONSTRAINT FK_PerformanceMetrics_Provider FOREIGN KEY (ProviderId) REFERENCES SmppProviders(ProviderId)
);

-- ============================================
-- INDEXES for Performance Optimization
-- ============================================

-- SmsMessages Indexes
CREATE INDEX IX_SmsMessages_Status ON SmsMessages(Status);
CREATE INDEX IX_SmsMessages_ProviderId ON SmsMessages(ProviderId);
CREATE INDEX IX_SmsMessages_DestinationAddress ON SmsMessages(DestinationAddress);
CREATE INDEX IX_SmsMessages_CreatedDate ON SmsMessages(CreatedDate);
CREATE INDEX IX_SmsMessages_ExternalMessageId ON SmsMessages(ExternalMessageId);
CREATE INDEX IX_SmsMessages_ScheduledTime ON SmsMessages(ScheduledTime) WHERE ScheduledTime IS NOT NULL;

-- DeliveryReports Indexes
CREATE INDEX IX_DeliveryReports_MessageId ON DeliveryReports(MessageId);
CREATE INDEX IX_DeliveryReports_ExternalMessageId ON DeliveryReports(ExternalMessageId);
CREATE INDEX IX_DeliveryReports_IsProcessed ON DeliveryReports(IsProcessed);
CREATE INDEX IX_DeliveryReports_ReceivedTime ON DeliveryReports(ReceivedTime);

-- SmsQueue Indexes
CREATE INDEX IX_SmsQueue_QueueStatus ON SmsQueue(QueueStatus);
CREATE INDEX IX_SmsQueue_Priority ON SmsQueue(Priority DESC);
CREATE INDEX IX_SmsQueue_ScheduledTime ON SmsQueue(ScheduledTime) WHERE ScheduledTime IS NOT NULL;

-- SystemLogs Indexes
CREATE INDEX IX_SystemLogs_LogLevel ON SystemLogs(LogLevel);
CREATE INDEX IX_SystemLogs_Category ON SystemLogs(Category);
CREATE INDEX IX_SystemLogs_CreatedDate ON SystemLogs(CreatedDate);

-- ============================================
-- STORED PROCEDURES
-- ============================================

-- Get Next Message from Queue
GO
CREATE PROCEDURE sp_GetNextQueuedMessage
    @ProviderId INT
AS
BEGIN
    SET NOCOUNT ON;
    
    SELECT TOP 1 
        q.QueueId,
        q.MessageId,
        q.ProviderId,
        m.*
    FROM SmsQueue q
    INNER JOIN SmsMessages m ON q.MessageId = m.MessageId
    WHERE q.QueueStatus = 'QUEUED'
        AND q.ProviderId = @ProviderId
        AND (q.ScheduledTime IS NULL OR q.ScheduledTime <= GETDATE())
    ORDER BY q.Priority DESC, q.CreatedDate ASC;
END;
GO

-- Update Message Status
GO
CREATE PROCEDURE sp_UpdateMessageStatus
    @MessageId BIGINT,
    @Status NVARCHAR(50),
    @ExternalMessageId NVARCHAR(100) = NULL,
    @ErrorCode NVARCHAR(50) = NULL,
    @ErrorMessage NVARCHAR(500) = NULL
AS
BEGIN
    SET NOCOUNT ON;
    
    UPDATE SmsMessages
    SET Status = @Status,
        ExternalMessageId = ISNULL(@ExternalMessageId, ExternalMessageId),
        ErrorCode = @ErrorCode,
        ErrorMessage = @ErrorMessage,
        SubmittedTime = CASE WHEN @Status = 'SUBMITTED' THEN GETDATE() ELSE SubmittedTime END,
        DeliveredTime = CASE WHEN @Status = 'DELIVERED' THEN GETDATE() ELSE DeliveredTime END,
        UpdatedDate = GETDATE()
    WHERE MessageId = @MessageId;
END;
GO

-- Insert Delivery Report
GO
CREATE PROCEDURE sp_InsertDeliveryReport
    @MessageId BIGINT,
    @ExternalMessageId NVARCHAR(100),
    @ProviderId INT,
    @DlrStatus NVARCHAR(50),
    @DlrText NVARCHAR(MAX) = NULL,
    @ErrorCode NVARCHAR(50) = NULL,
    @NetworkCode NVARCHAR(50) = NULL
AS
BEGIN
    SET NOCOUNT ON;
    
    BEGIN TRANSACTION;
    
    -- Insert delivery report
    INSERT INTO DeliveryReports (MessageId, ExternalMessageId, ProviderId, DlrStatus, DlrText, ErrorCode, NetworkCode)
    VALUES (@MessageId, @ExternalMessageId, @ProviderId, @DlrStatus, @DlrText, @ErrorCode, @NetworkCode);
    
    -- Update message status based on DLR
    DECLARE @NewStatus NVARCHAR(50);
    
    SET @NewStatus = CASE @DlrStatus
        WHEN 'DELIVRD' THEN 'DELIVERED'
        WHEN 'EXPIRED' THEN 'EXPIRED'
        WHEN 'UNDELIV' THEN 'FAILED'
        WHEN 'REJECTD' THEN 'REJECTED'
        ELSE 'SUBMITTED'
    END;
    
    EXEC sp_UpdateMessageStatus @MessageId, @NewStatus, NULL, @ErrorCode, @DlrText;
    
    COMMIT TRANSACTION;
END;
GO

-- Get Provider Statistics
GO
CREATE PROCEDURE sp_GetProviderStatistics
    @ProviderId INT,
    @StartDate DATETIME,
    @EndDate DATETIME
AS
BEGIN
    SET NOCOUNT ON;
    
    SELECT 
        p.ProviderName,
        COUNT(*) AS TotalMessages,
        SUM(CASE WHEN m.Status = 'DELIVERED' THEN 1 ELSE 0 END) AS DeliveredCount,
        SUM(CASE WHEN m.Status = 'FAILED' THEN 1 ELSE 0 END) AS FailedCount,
        SUM(CASE WHEN m.Status = 'PENDING' THEN 1 ELSE 0 END) AS PendingCount,
        AVG(DATEDIFF(SECOND, m.SubmittedTime, m.DeliveredTime)) AS AvgDeliveryTimeSeconds,
        CAST(SUM(CASE WHEN m.Status = 'DELIVERED' THEN 1 ELSE 0 END) * 100.0 / COUNT(*) AS DECIMAL(5,2)) AS SuccessRate
    FROM SmsMessages m
    INNER JOIN SmppProviders p ON m.ProviderId = p.ProviderId
    WHERE m.ProviderId = @ProviderId
        AND m.CreatedDate BETWEEN @StartDate AND @EndDate
    GROUP BY p.ProviderName;
END;
GO

-- ============================================
-- SAMPLE DATA
-- ============================================

-- Insert Sample Providers
INSERT INTO SmppProviders (ProviderName, ProviderCode, Host, Port, SystemId, Password, BindType, IsActive, IsPrimary, Priority, MaxTPS)
VALUES 
('Primary SMS Provider', 'PROVIDER1', 'smpp.provider1.com', 2775, 'user123', 'encrypted_pass123', 'TRANSCEIVER', 1, 1, 1, 50),
('Backup SMS Provider', 'PROVIDER2', 'smpp.provider2.com', 2775, 'user456', 'encrypted_pass456', 'TRANSCEIVER', 1, 0, 2, 30);

-- Insert Sample Templates
INSERT INTO SmsTemplates (TemplateName, TemplateCode, MessageText, Parameters, IsActive)
VALUES 
('Welcome Message', 'WELCOME', 'Welcome {Name}! Thank you for registering with us.', '["Name"]', 1),
('OTP Message', 'OTP', 'Your OTP is {OTP}. Valid for {Minutes} minutes.', '["OTP", "Minutes"]', 1),
('Order Confirmation', 'ORDER_CONF', 'Your order #{OrderId} has been confirmed. Total: ${Amount}', '["OrderId", "Amount"]', 1);

GO

-- ============================================
-- VIEWS for Reporting
-- ============================================

-- Daily Summary View
CREATE VIEW vw_DailySummary
AS
SELECT 
    CAST(m.CreatedDate AS DATE) AS MessageDate,
    p.ProviderName,
    COUNT(*) AS TotalMessages,
    SUM(CASE WHEN m.Status = 'DELIVERED' THEN 1 ELSE 0 END) AS Delivered,
    SUM(CASE WHEN m.Status = 'FAILED' THEN 1 ELSE 0 END) AS Failed,
    SUM(CASE WHEN m.Status = 'PENDING' THEN 1 ELSE 0 END) AS Pending,
    SUM(CASE WHEN m.Status = 'SUBMITTED' THEN 1 ELSE 0 END) AS Submitted
FROM SmsMessages m
INNER JOIN SmppProviders p ON m.ProviderId = p.ProviderId
GROUP BY CAST(m.CreatedDate AS DATE), p.ProviderName;
GO

-- Failed Messages View
CREATE VIEW vw_FailedMessages
AS
SELECT 
    m.MessageId,
    m.ExternalMessageId,
    p.ProviderName,
    m.DestinationAddress,
    m.MessageText,
    m.Status,
    m.ErrorCode,
    m.ErrorMessage,
    m.RetryCount,
    m.CreatedDate
FROM SmsMessages m
INNER JOIN SmppProviders p ON m.ProviderId = p.ProviderId
WHERE m.Status IN ('FAILED', 'REJECTED', 'EXPIRED');
GO

PRINT 'Database schema created successfully!';
